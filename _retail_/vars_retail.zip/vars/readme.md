manage cvar settings in World of Warcraft

![warcraft-cvars](https://i.imgur.com/RDINSy9.png)

b v carefy with this. advise against using unless you know what you are doing =p

/vars config
