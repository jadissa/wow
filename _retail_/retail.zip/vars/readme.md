manage cvar settings in World of Warcraft

<img src="https://i.imgur.com/RDINSy9.png" width="200" />

initial version

/vars config